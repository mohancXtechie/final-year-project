EVIDENCE PACKAGE CONTENTS
==========================
Subject User : DTAA/SJH0588
Generated    : 2026-04-22 19:26:44

Files:
  forensic_report.pdf    - Full forensic investigation report (share with Legal)
  user_risk_profile.csv  - Complete risk scores from all detection layers
  suspicious_events.csv  - Timeline of suspicious raw log events
  ueba_scores.csv        - Statistical behavioral scores per feature
  detection_summary.txt  - Plain text summary (share with HR)
  README.txt             - This file
